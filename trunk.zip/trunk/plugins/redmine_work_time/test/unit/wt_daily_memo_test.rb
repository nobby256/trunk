require File.dirname(__FILE__) + '/../test_helper'

class WtDailyMemoTest < Test::Unit::TestCase
  fixtures :wt_daily_memos

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
