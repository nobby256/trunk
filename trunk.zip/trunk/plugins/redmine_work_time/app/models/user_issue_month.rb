class UserIssueMonth < ActiveRecord::Base
end
