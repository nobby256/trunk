class WtMemberOrder < ActiveRecord::Base
end
