class WtTicketRelay < ActiveRecord::Base
end
