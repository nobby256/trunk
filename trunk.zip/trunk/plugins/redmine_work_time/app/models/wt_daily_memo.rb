class WtDailyMemo < ActiveRecord::Base
end
