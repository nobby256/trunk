class WtHolidays < ActiveRecord::Base
end
