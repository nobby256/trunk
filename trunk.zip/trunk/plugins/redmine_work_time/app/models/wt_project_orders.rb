class WtProjectOrders < ActiveRecord::Base
end
