Redmine Collapsed Journals Plugin
=================================

Collapses issue history items without an assosiated note.

Translated into 4 languages: English, German, Russian, Ukrainian.

This plugin is the fork of [Hide Journal Details](http://www.redmine.org/plugins/hide_journal_details) plugin by [Jürgen Diez](http://www.redmine.org/users/76374).

Screenshot
----------
![Redmine Collapsed Journals Plugin Screenshot](https://github.com/stgeneral/redmine-collapsed-journals/releases/download/v0.0.2/collapsed-journals-screenshot.png)

Installation notes
------------------

Plugin's directory should be named `collapsed_journals` exactly.

Other installation instructions are generic and can be found at [Redmine Plugins page](http://www.redmine.org/projects/redmine/wiki/Plugins).

Compatible with Redmine 2.4, 2.3, 2.2.
