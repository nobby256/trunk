# redmine_issue_no_parent_update
子チケットの変更を親チケットに反映させない（開始日/期日/優先度）プラグイン
