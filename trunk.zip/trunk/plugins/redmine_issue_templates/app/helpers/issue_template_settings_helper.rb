module IssueTemplateSettingsHelper
end
