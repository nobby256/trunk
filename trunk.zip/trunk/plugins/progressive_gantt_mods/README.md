Progressive Gantt Mods
=========================

Assignee column and some preferences for Gantt chart.

![Progressive Gantt Mods Screenshot](https://github.com/stgeneral/redmine-progressive-gantt-mods/releases/download/v0.0.1/progressive_gantt_mods-screen-en.png)


Compatible with [Redmine](http://www.redmine.org/) 2.4.

Other Proressive plugins for Redmine
------------------------------------

* [Progressive Projects List](http://stgeneral.github.io/redmine-progressive-projects-list/) - overall projects status on one page.
* [Progressive Redmine Theme](http://stgeneral.github.io/redmine-progressive-theme/) - extends default theme with some nice features.
* [Progressive Gantt Mods](https://github.com/stgeneral/redmine-progressive-gantt-mods) - assignee column and some preferences for Gantt chart.
