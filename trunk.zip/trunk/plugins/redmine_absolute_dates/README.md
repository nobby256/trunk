absolute_dates
===================

[![Code Climate](https://codeclimate.com/github/suer/redmine_absolute_dates.png)](https://codeclimate.com/github/suer/redmine_absolute_dates)

This Plugin support Japanese environment only!

機能
---------------------

Redmineのチケットの作成日、更新日はデフォルトでは
「今日」からの相対的な日時数で表示されます。(...日前など)

このプラグインはこの日付を通常の日付(yyyy/MM/dd)で表示します。

インストール
---------------------

1. Redmineのインストールディレクトリ内の vender/plugins/ にて

   $ git clone git://github.com/suer/redmine_absolute_dates.git

2. Redmine の再起動

ライセンス
---------------------

MITライセンスとします

