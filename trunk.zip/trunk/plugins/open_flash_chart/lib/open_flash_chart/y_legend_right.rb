module OpenFlashChart

  class YLegendRight < YLegend
  end

end
