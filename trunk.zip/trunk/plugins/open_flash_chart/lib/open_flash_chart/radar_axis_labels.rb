module OpenFlashChart

  class RadarAxisLabels < Base
    def initialize(labels, args={})
      super args
      @labels = labels      
    end
  end

end