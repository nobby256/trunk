module OpenFlashChart

  class XAxisLabels < Base
    def set_vertical
      @rotate = 270
    end
  end

end
