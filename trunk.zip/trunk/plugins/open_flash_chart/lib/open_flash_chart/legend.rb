module OpenFlashChart

  class Legend < Base
  end

end

