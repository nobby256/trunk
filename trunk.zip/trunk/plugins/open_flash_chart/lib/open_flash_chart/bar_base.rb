module OpenFlashChart
  class BarBase < Base
    def attach_to_right_y_axis
      @axis = 'right'
    end    
  end
end
