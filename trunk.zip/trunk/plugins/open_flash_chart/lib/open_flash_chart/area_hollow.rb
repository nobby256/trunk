module OpenFlashChart

  class AreaHollow < AreaBase
    def initialize args={}
      super
      @type = "area_hollow"      
    end
  end

end