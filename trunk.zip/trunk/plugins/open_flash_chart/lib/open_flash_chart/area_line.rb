module OpenFlashChart

  class AreaLine < AreaBase
    def initialize args={}
      super
      @type = "area_line"      
    end
  end

end