module OpenFlashChart
  class YAxisRight < YAxisBase
  end
end
