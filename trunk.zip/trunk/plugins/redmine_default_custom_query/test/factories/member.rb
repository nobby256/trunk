FactoryGirl.define do
  factory :member do
    mail_notification 0
  end
end
