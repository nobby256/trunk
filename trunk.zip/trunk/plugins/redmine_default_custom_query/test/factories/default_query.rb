FactoryGirl.define do
  factory :default_query, class: ProjectsDefaultQuery do
  end
end
