FactoryGirl.define do
  factory :enabled_module do
    factory :default_custom_query_module do
      name 'default_custom_query'
    end
  end
end
