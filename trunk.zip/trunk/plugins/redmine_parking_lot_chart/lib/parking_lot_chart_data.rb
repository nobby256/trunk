class ParkingLotChartData
  def initialize
    
  end

  attr_accessor :id, :name, :estimated_hours,
    :open_issues_count, :closed_issues_count, :effective_date, :status,
    :open_issues_pourcent, :closed_issues_pourcent, :issues_status
end
